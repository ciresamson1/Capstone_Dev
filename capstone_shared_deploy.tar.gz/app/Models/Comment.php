<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $fillable = [
        'sub_task_id',
        'user_id',
        'message'
    ];

    public function subTask()
    {
        return $this->belongsTo(SubTask::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}